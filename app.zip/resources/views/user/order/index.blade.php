@extends('user.layouts.app', ['isSidebar' => true, 'isNavbar' => true, 'isFooter' => true])
@section('dashboard', 'active')
@section('content')
    <div class="dashboard_mainsec">
        <!-- statistical information -->
        <h3 class="heading_title">My Order</h3>
        <div class="stats_box row">
         <h2>My Order</h2>
        </div>
    </div>
@endsection
