
<?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard_mainsec">
        <!-- statistical information -->
        <h3 class="heading_title">Statistical Information</h3>
        <div class="stats_box row">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', ['isSidebar' => true, 'isNavbar' => true, 'isFooter' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\momKichan\resources\views/user/dashboard/index.blade.php ENDPATH**/ ?>