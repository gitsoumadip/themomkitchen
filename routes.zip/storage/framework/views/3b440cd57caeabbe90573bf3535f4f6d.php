
<?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <section class="menu_sec">
        <div class="container">
            
            <div class="row">
                <div class="col-12">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-starters" role="tabpanel"
                            aria-labelledby="pills-starters-tab">
                            <div class="menutab_con">
                                <form action="<?php echo e(route('order.dalivery-address.add-edit')); ?>" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-ml-4">
                                            <input type="text" name="name" id="name" placeholder="Name">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" class="" name="phone" required=""
                                                maxlength="10" autocomplete="tel" tabindex="2" value=""
                                                placeholder="10-digit mobile number">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="pincode" id="pincode" maxlength="6"
                                                placeholder="Pincode">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="locality" id="locality" placeholder="Locality">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="address" id="address" placeholder="address">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="city" id="city" placeholder="city">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="state" id="state" placeholder="state">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="landmark" id="landmark" placeholder="landmark">
                                        </div>
                                        <div class="col-ml-4">
                                            <input type="text" name="alter_phone" id="alter_phone"
                                                placeholder="alter phone">
                                        </div>
                                        <div class="col-ml-4">
                                            <label for="">Home</label>
                                            <input type="radio" name="type" id="type" value="home">
                                        </div>
                                        <div class="col-ml-4">
                                            <label for="">Office</label>
                                            <input type="radio" name="type" id="type" value="office">
                                        </div>
                                    </div>
                                    

                                    <div class="col-8">
                                        <div class="menus_right_button d-flex justify-content-end">

                                            <a href="<?php echo e(route('menu')); ?>"> <button type="button" class="place_order">Place
                                                    Order</button></a>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class="go-top"><i class="fa fa-angle-double-up" aria-hidden="true"></i></div>
    <div id="preloader">
        <div class="ripple_effect">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', ['isSidebar' => true, 'isNavbar' => true, 'isFooter' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\momKichan\resources\views/frontend/order/dalivery-address/add-edit.blade.php ENDPATH**/ ?>