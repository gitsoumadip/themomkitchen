<!-- header section starts  -->



<header class="main-nav">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-3 col-6">
                <div class="logo">
                    <a href=""> <img src="<?php echo e(asset('assets/images/weblogo.png')); ?>" class="img-fluid" alt=""
                            width="250px" height="180px"></a>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-6 mb-2">
                
                
                <div class="row-6">
                    <div class="header-left">
                        <div class="stellarnav">
                            <ul>
                              
                                <li class="active"><a href="<?php echo e(route('home')); ?>"><i
                                            class="fa-solid fa-house-user"></i>Home </a></li>
                                <li><a href="<?php echo e(route('menu')); ?>"><i class="fa-solid fa-bars"></i>Menu</a></li>

                                <a href="<?php echo e(route('cart')); ?>"><i class="fas fa-shopping-cart"
                                        id="shopping-cart"></i></a>
                                <?php if(isset(auth()->user()->id)): ?>
                                    <li></li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                                    <li></li><a href="<?php echo e(route('user.dashboard.home')); ?>">Profile</a></li>
                                <?php else: ?>
                                    <li></li><a href="<?php echo e(route('login')); ?>"><i class="fas fa-user"
                                            id="user"></i></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\momKichan\resources\views/frontend/layouts/partials/navbar.blade.php ENDPATH**/ ?>