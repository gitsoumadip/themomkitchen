<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    use HasFactory;
    protected $fillable = [
        'type_id',
        'item_id'
    ];

    function types()
    {
        return $this->belongsTo(Type::class, 'type_id');
    }

    function items()
    {
        return $this->belongsTo(Item::class, 'item_id');
    }
}
