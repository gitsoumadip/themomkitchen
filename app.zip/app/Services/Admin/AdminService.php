<?php

namespace App\Services\Admin;

use App\Contracts\Admin\AdminContracts;
use App\Contracts\Auth\AuthContract;
use Illuminate\Support\Facades\Auth;


class AdminService implements AdminContracts
{

    // public function findEmail(array $data)
    // {
    //     $query = SELF_MODEL::where('email', $data['email'])->first();
    //     return $query;
    // }
}
