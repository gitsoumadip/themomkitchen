<?php

use App\Http\Controllers\Clinic\ClinicController;
use App\Http\Controllers\Doctor\DoctorController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth'])->group(function () {

});
