
<?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->startSection('content'); ?>

    <!-- menu sec -->
    <section class="menu_sec">
        <div class="container">
            <div class="heading_box">
                <div class="menu-icon"><img src="<?php echo e(asset('assets/images/our-menu.png')); ?>" class="img-fluid" alt=""
                        width="200px" height="180px"></div>
                <h2><U>Our Menu</U></h2>
                
            </div>
            <div class="row">
                <div class="col-12">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-starters-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-starters" type="button" role="tab"
                                aria-controls="pills-starters" aria-selected="true">Lunch <span><img
                                        src="<?php echo e(asset('assets/images/starters.png')); ?>" class="img-fluid"
                                        alt=""></span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-maindish-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-maindish" type="button" role="tab"
                                aria-controls="pills-maindish" aria-selected="false">Dinner <span><img
                                        src="<?php echo e(asset('assets/images/main.png')); ?>" class="img-fluid"
                                        alt=""></span></button>
                        </li>

                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-starters" role="tabpanel"
                            aria-labelledby="pills-starters-tab">
                            <div class="menutab_con">
                                <div class="row">
                                    <?php $__currentLoopData = $fetchTypeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <div class="col-md-6">
                                            <div class="menu_singlebox">
                                                <div class="menus_left">
                                                    <img src="<?php echo e(asset('assets/images/food1.jpg')); ?>" class="img-fluid"
                                                        alt="">
                                                </div>
                                                <div class="menus_middle">
                                                    <h4><?php echo e($data->name); ?></h4>
                                                    <p><?php echo e($data->description); ?></p>
                                                    <span class="item_price"> <i class="fa-solid fa-indian-rupee-sign">
                                                            Rs<?php echo e($data->price); ?></i></span>
                                                </div>

                                                <div class="menus_right">
                                                    <?php if(!empty(auth()->user()->id)): ?>
                                                        <a href="#"class="addToCart " data-id="<?php echo e($data->id); ?>"><i
                                                                class="fa-solid fa-cart-plus fa-2xl"
                                                                style="color: #ffa800;"></i></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('login')); ?>"class="addToCart add_cart"><i
                                                                class="fa-solid fa-cart-plus fa-2xl"
                                                                style="color: #ffa800;"></i></a>
                                                    <?php endif; ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-maindish" role="tabpanel" aria-labelledby="pills-maindish-tab">
                            <div class="menutab_con">

                                <div class="row">
                                    <?php $__currentLoopData = $fetchTypeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="menu_singlebox">
                                                <div class="menus_left">
                                                    <img src="<?php echo e(asset('assets/images/food1.jpg')); ?>" class="img-fluid"
                                                        alt="">
                                                </div>
                                                <div class="menus_middle">
                                                    <h4>GARLIC BREAD</h4>
                                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita,
                                                        atque.</p>
                                                </div>
                                                <div class="menus_right">
                                                    <?php if(!empty(auth()->user()->id)): ?>
                                                        <a href="#" class="add_cart"><i
                                                                class="fa-solid fa-cart-plus fa-2xl"
                                                                style="color: #ffa800;"></i></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('login')); ?>" class=""><i
                                                                class="fa-solid fa-cart-plus fa-2xl"
                                                                style="color: #ffa800;"></i></a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="go-top"><i class="fa fa-angle-double-up" aria-hidden="true"></i></div>

    <div id="preloader">
        <div class="ripple_effect">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '.addToCart', function() {
            let addtocart = $(this).attr('data-id');
            // alert(addtocart);
            // Example using jQuery
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "<?php echo e(route('cart.addToCart')); ?>",
                type: 'POST',
                data: {
                    id: addtocart
                },
                success: function(response) {
                    console.log(response);
                    // alert('kjhgfdsdfghj');
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });


        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', ['isSidebar' => true, 'isNavbar' => true, 'isFooter' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\momKichan\resources\views/frontend/menu/index.blade.php ENDPATH**/ ?>