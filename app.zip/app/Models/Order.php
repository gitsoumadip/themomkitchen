<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $guarded = [];

    function types()
    {
        return $this->belongsTo(Type::class, 'type_id');
    }
    function users()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    function orderDetails()
    {
        return $this->belongsTo(OrderDetails::class, 'order_details_id');
    }
}
// types,users,orderDetails