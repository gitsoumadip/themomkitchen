<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <section class="login-sec">
        <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid p-0">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>
</body>

<?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\xampp\htdocs\momKichan\resources\views/layouts/auth.blade.php ENDPATH**/ ?>