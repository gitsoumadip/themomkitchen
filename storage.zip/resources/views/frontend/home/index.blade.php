@extends('frontend.layouts.app', ['isSidebar' => true, 'isNavbar' => true, 'isFooter' => true])
@section('dashboard', 'active')
@section('content')

    <div class="banner">
        <!-- Swiper -->
        <div class="hero_img">
            <div swiper_scale_active class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="{{ asset('assets/images/hero01.jpg') }}" class="img-fluid" />

                        <!-- <a href="#" id="form">Link</a> -->
                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="{{ asset('assets/images/hero02.jpg') }}" class="img-fluid" />
                            <!-- <a href="#">Link 2</a> -->
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <img src="{{ asset('assets/images/hero03.jpg') }}" class="img-fluid" />

                        <!-- <a href="#">Link 3</a> -->
                    </div>
                    <div class="swiper-slide">
                        <img src="{{ asset('assets/images/hero04.jpg') }}" class="img-fluid" />
                        <!-- <a href="#">Link 4</a> -->
                    </div>

                </div>
            </div>
            <div class="heroi_con">
                <h3>Dinner With us <span class="header-sub-title" id="word"></span> <span
                        class="header-sub-title blink">|</span></h3>
                <p>We are an Indian food store that produces tasty, delectable, appetizing, mouth-watering food. We deliver
                    the
                    best, delicious</p>
            </div>
        </div>
    </div>

    <!-- contact us button -->
    <div class="contactus">
        <a href="{{ route('menu') }}">
            <button>Order Now</button></a>
    </div>


    <div class="go-top"><i class="fa fa-angle-double-up" aria-hidden="true"></i></div>

    <div id="preloader">
        <div class="ripple_effect">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>











    <!-- header section starts  -->
    {{-- <header class="header">
        <a href="#" class="logo">
            <!-- <img src="Image/logo1.jpg" alt="" class="img-log"> -->
            Mom's Kitchen
            <!-- <i class="fas fa-utensils"></i> -->

            <i class="fa-brands fa-instagram"></i>
            <i class="fa-brands fa-facebook-f"></i>
        </a>
        <nav class="navbar">
            <a class="active" href="index.html">Home</a>
            <a href="menu.html">Menu</a>
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#contact us">Contact Us</a>
            <a href="test.html">Contact Us</a>
        </nav>

        <di class="icons">
            <i class="fas fa-bars" id="menu-bars"></i>
            <!-- <i class="fas fa-search" id="search"></i> -->
            <i class="fas fa-shopping-cart" id="shopping-cart"></i>
            <i class="fas fa-user" id="user"></i>

        </di>
    </header> --}}

    {{-- <section class="home" id="home">
        <div class="swiper mySwiper home-slider">
            <div class="swiper-wrapper wrapper">
                <div class="swiper-slide slide">
                    <div class="content">
                        <span>Welcome to you</span>
                        <h3>The Mom's Kitchen</h3>
                        <p>Your Mom's touch in every bite </p>
                        <a href="#" class="btn">Order Now</a>
                    </div>
                    <div class="image">
                        <img src="{{ asset('assets/Image/logo1.jpg') }}" alt="" width="70%" height="70%"
                            class="img-logo">
                    </div>
                </div>

                <div class="swiper-slide slide">
                    <div class="content">
                        <span>Our Special Dish</span>
                        <h3>Spicy Chiken</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, illo!</p>
                        <a href="#" class="btn">Order Now</a>
                    </div>
                    <div class="image">
                        <img src="{{ asset('assets/Image/chhola.jpg') }}" alt="">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="content">
                        <span>Our Special Dish</span>
                        <h3>Spicy Chiken</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, illo!</p>
                        <a href="#" class="btn">Order Now</a>
                    </div>
                    <div class="image">
                        <img src="{{ asset('assets/Image/dosa.jpg') }}" alt="">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="content">
                        <span>Our Special Dish</span>
                        <h3>Spicy Chiken</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, illo!</p>
                        <a href="#" class="btn">Order Now</a>
                    </div>
                    <div class="image">
                        <img src="{{ asset('assets/Image/gujrati.jpeg') }}" alt="">
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="content">
                        <span>Our Special Dish</span>
                        <h3>Spicy Chiken</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, illo!</p>
                        <a href="#" class="btn">Order Now</a>
                    </div>
                    <div class="image">
                        <img src="{{ asset('assets/Image/paneer.jpg') }}" alt="">
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
    <!-- home section ends -->


    <!-- Banner Section start -->
    <section class="banner section-m1">

        <button class="btn btn-primary">Explore More</button>

    </section> --}}

    <!-- Custom js file link -->
@endsection
@push('scripts')
@endpush
