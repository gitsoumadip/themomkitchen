<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="login-sec">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col-md-6">
                    <div class="login-secleft">
                        <div class="loginleft_logo">
                            <img src="assets/images/logo.svg" class="img-fluid" alt="">
                        </div>
                        <div class="loginleft_img">
                            <img src="assets/images/login-leftimg.svg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="login-secright">
                        <div class="login-rightbox">
                            <h3>Login User</h3>
                            <div class="line-around-flex"></div>
                            <form id="formAuthentication" class="mb-3" action="<?php echo e(route('user.login')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="single-login">
                                    <label class="login-label"> Username / Email ID</label>
                                    <input class="form-control" type="text" name="email" id="email"
                                        placeholder="Enter User Name or Email ID">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="single-login">
                                    <label class="login-label"> Password</label>
                                    <input id="password-eye" type="password" placeholder="Password" class="form-control"
                                        name="password" value="">
                                    <span toggle="#password-eye" class="fa fa-fw fa-eye eye-icon toggle-eye"></span>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                    
                                <button class="btn btn-primary btn-effect btn-effect-arrow mt-4">
                                    Login
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        // login page password
        $(".toggle-eye").click(function() {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\momKichan\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>